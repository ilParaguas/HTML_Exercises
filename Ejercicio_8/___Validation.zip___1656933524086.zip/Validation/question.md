Given the starting form, validate the fields:

- All fields should be marked as mandatory
- Fields related to credit card and CVC should have a validation about the maximum length.
