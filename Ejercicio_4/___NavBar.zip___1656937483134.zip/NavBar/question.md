
Try to replicate the navbar html structure in the png file, without using CSS properties.
**Suggestion**
In order to replicate the navbar html structure, try to use the semantic tag `<nav>`. For the links try to use a not ordered list.
