
Create a HTML blog page.
* The page should have an article, a footer and a form.
* The article should have a title, a paragraph and background pictures.
* The form should have a mandatory email field and a submit button.

Use semantic tags as much as possible.
