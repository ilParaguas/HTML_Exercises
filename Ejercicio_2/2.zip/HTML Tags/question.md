# HTML Tags

Some of HTML tags have a pre-sect structure due to the browser's rules. Try to replicate the same html structure of the solution.png with the right tags.
The head tag contains the style tag, ignore it for now.

Suggestion:
Use the below link as a reference to find the right tags. Look at the solution.png
[https://www.w3schools.com/TAgs/default.asp](https://www.w3schools.com/TAgs/default.asp)
