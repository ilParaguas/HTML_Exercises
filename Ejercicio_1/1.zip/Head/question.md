
Add to the `head` the tags for title, description, author, favicon and the other properties of Open Graph protocol.
