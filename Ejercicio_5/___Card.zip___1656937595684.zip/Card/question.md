
Replicate the html structure of the card in the png file, without applying CSS properties.

**Suggestion**
Try to use the html article tag in order to replicate the card's structure.
